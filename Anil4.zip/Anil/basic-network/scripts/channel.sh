
#docker exec -e "CORE_PEER_LOCALMSPID=Org1MSP" -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@org1.example.com/msp" peer0.org1.example.com
#CORE_PEER_LOCALMSPID=Org1MSP
#CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@org1.example.com/msp
#docker exec -e "CORE_PEER_LOCALMSPID=Org1MSP" -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@org1.example.com/msp" peer0.org1.example.com peer channel create --logging-level=DEBUG -c mychannel -f /etc/hyperledger/configtx/channel.tx -o orderer.example.com:7050 --tls --cafile /etc/hyperledger/msp/orderer/msp/cacerts/ca.example.com-cert.pem --clientauth --keyfile /etc/hyperledger/crypto/orderer/tls/server.key --certfile /etc/hyperledger/crypto/orderer/tls/server.crt







export CORE_PEER_LOCALMSPID="Org1MSP"
export CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt
export CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp
export CORE_PEER_ADDRESS=peer0.org1.example.com:7051		
export CORE_PEER_TLS_CERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/server.crt
export CORE_PEER_TLS_KEY_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/server.key      
	
peer channel create --logging-level=DEBUG -c mychannel -f /etc/hyperledger/configtx/channel.tx -o orderer.example.com:7050 --tls --cafile /etc/hyperledger/msp/orderer/msp/tlscacerts/tlsca.example.com-cert.pem --clientauth --keyfile /etc/hyperledger/msp/orderer/tls/server.key --certfile /etc/hyperledger/msp/orderer/tls/server.crt

export CORE_PEER_LOCALMSPID="Org1MSP"
export CORE_PEER_TLS_ROOTCERT_FILE=/etc/hyperledger/msp/peer/tls/ca.crt
#export CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/peer/msp		
export CORE_PEER_ADDRESS=peer0.org1.example.com:7051		
export CORE_PEER_TLS_CERT_FILE=/etc/hyperledger/msp/peer/tls/server.crt
export CORE_PEER_TLS_KEY_FILE=/etc/hyperledger/msp/peer/tls/server.key      



   export PEER_HOST=peer0.org1.example.com
   export FABRIC_CA_CLIENT=/etc/hyperledger/fabric-ca-server
   export CORE_PEER_ID=$PEER_HOST
   export CORE_PEER_ADDRESS=$PEER_HOST:7051
   export CORE_VM_ENDPOINT=unix:///host/var/run/docker.sock
   # the following setting starts chaincode containers on the same
   # bridge network as the peers
   # https://docs.docker.com/compose/networking/
   #export CORE_VM_DOCKER_HOSTCONFIG_NETWORKMODE=${COMPOSE_PROJECT_NAME}_${NETWORK}
   export CORE_LOGGING_LEVEL=DEBUG
   export CORE_PEER_TLS_ENABLED=true
   export CORE_PEER_TLS_CLIENTAUTHREQUIRED=true
   export CORE_PEER_TLS_CLIENTCERT_FILE=/etc/hyperledger/msp/peer/tls/server.crt
   export CORE_PEER_TLS_CLIENTKEY_FILE=/etc/hyperledger/msp/peer/tls/server.key      
   export CORE_PEER_PROFILE_ENABLED=true
   # gossip variables
   export CORE_PEER_GOSSIP_USELEADERELECTION=true
   export CORE_PEER_GOSSIP_ORGLEADER=false
   export CORE_PEER_GOSSIP_EXTERNALENDPOINT=$PEER_HOST:7051
   export CORE_PEER_GOSSIP_BOOTSTRAP=peer0.org1.example.com:7051

    export ORDERER_HOST=orderer.example.com #orderer${NUM}-${ORG}
   export ORDERER_NAME=admin #orderer${NUM}-${ORG}
   export ORDERER_PASS=adminpw
   admin ORDERER_NAME_PASS=admin:adminpw
   
   export ORDERER_GENERAL_LOGLEVEL=debug
   export ORDERER_GENERAL_LISTENADDRESS=0.0.0.0
   export ORDERER_GENERAL_GENESISMETHOD=file
   export ORDERER_GENERAL_GENESISFILE=/etc/hyperledger/configtx/genesis.block
   export ORDERER_GENERAL_LOCALMSPID="Org1MSP"
   # enabled TLS
   export ORDERER_GENERAL_TLS_ENABLED=true
   export TLSDIR=/etc/hyperledger/msp/orderer/tls
   export ORDERER_GENERAL_TLS_PRIVATEKEY=$TLSDIR/server.key
   export ORDERER_GENERAL_TLS_CERTIFICATE=$TLSDIR/server.crt
   #export ORDERER_GENERAL_TLS_ROOTCAS=[$CA_CHAINFILE]


peer channel join -b mychannel.block

#peer channel join -b mychannel.block -o orderer.example.com:7050 --certfile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/server.crt --keyfile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/server.key --tls

#CORE_PEER_TLS_CERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/server.crt
#CORE_PEER_TLS_KEY_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/server.key




export CC_SRC_PATH=github.com/fabcar/go

peer chaincode install -n fabcar -v 1.0 -p "$CC_SRC_PATH" -l golang
###peer chaincode instantiate -o orderer.example.com:7050 -C mychannel -n fabcar -l golang -v 1.0 -c '{"Args":[""]}' -P "OR ('Org1MSP.member','Org2MSP.member')"


peer chaincode instantiate -C mychannel -n fabcar -v 1.0 -c '{"Args":[""]}' -P "OR ('Org1MSP.member','Org2MSP.member')" -o orderer.example.com:7050 --tls --cafile /etc/hyperledger/msp/orderer/msp/tlscacerts/tlsca.example.com-cert.pem --clientauth --keyfile /etc/hyperledger/msp/orderer/tls/server.key --certfile /etc/hyperledger/msp/orderer/tls/server.crt

sleep 10
peer chaincode invoke -o orderer.example.com:7050 -C mychannel -n fabcar -c '{"function":"initLedger","Args":[""]}'  -o orderer.example.com:7050 --tls --cafile /etc/hyperledger/msp/orderer/msp/tlscacerts/tlsca.example.com-cert.pem --clientauth --keyfile /etc/hyperledger/msp/orderer/tls/server.key --certfile /etc/hyperledger/msp/orderer/tls/server.crt


export FABRIC_CA_CLIENT_HOME=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org1.example.com/users/Admin@org1.example.com
export FABRIC_CA_CLIENT_TLS_CERTFILES=/etc/hyperledger/fabric-ca-server-config/tlsca.org1.example.com-cert.pem
export CORE_PEER_MSPCONFIGPATH=$FABRIC_CA_CLIENT_HOME/msp

fabric-ca-client enroll -d -u https://admin:adminpw@ca.example.com:7054 --tls.client.certfile /etc/hyperledger/fabric-ca-server-config/tlsca.org1.example.com-cert.pem --tls.client.keyfile /etc/hyperledger/fabric-ca-server-config/ed3fd82393e95fc2c475afc113c8d2c591f745d1babc4d6d9cce0a1acc168acb_sk --enrollment.profile tls
      
   


#fabric-ca-client enroll -d -u https://admin:adminpw@$ca.example.com:7054 --tls.client.certfile /etc/hyperledger/fabric-ca-server-config/ca.org1.example.com-cert.pem --tls.client.keyfile /etc/hyperledger/fabric-ca-server-config/ed3fd82393e95fc2c475afc113c8d2c591f745d1babc4d6d9cce0a1acc168acb_sk --enrollment.profile tls

#fabric-ca-client register -d --id.name buyer --id.secret adminpw --id.attrs "hf.Registrar.Roles=client,hf.Registrar.Attributes=*,hf.Revoker=true,hf.GenCRL=true,role=buyer:ecert,abac.init=true:ecert"