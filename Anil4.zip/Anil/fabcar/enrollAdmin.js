'use strict';
/*
* Copyright IBM Corp All Rights Reserved
*
* SPDX-License-Identifier: Apache-2.0
*/
/*
 * Enroll the admin user
 */

var Fabric_Client = require('fabric-client');
var Fabric_CA_Client = require('fabric-ca-client');

var path = require('path');
var util = require('util');
var os = require('os');

//
var fabric_client = new Fabric_Client();
var fabric_ca_client = null;
var admin_user = null;
var member_user = null;
var store_path = path.join(__dirname, 'hfc-key-store');
console.log(' Store path:'+store_path);


var client = Fabric_Client.loadFromConfig("config/new-config.yaml");

	// This will load a connection profile over the top of the current one one
	// since the first one did not have a client section and the following one does
	// nothing will actually be replaced.
	// This will also set an admin identity because the organization defined in the
	// client section has one defined
	client.loadFromConfig("config/org1.yaml");

	// this will create both the state store and the crypto store based
	// on the settings in the client section of the connection profile
    client.initCredentialStores()
    .then((enrollment) => {
        client.getUserContext("admin", true)
    .then((user_from_store) => {

        if (user_from_store && user_from_store.isEnrolled()) {
            console.log('Successfully loaded admin from persistence');
            admin_user = user_from_store;
            return null;
        } else {
            console.log("enroll");
            //client.setUserContext({username: "admin", password: "adminpw"})
            //.then((enrollment) => {                
                let caClient = client.getCertificateAuthority();
                caClient.enroll({
                    enrollmentID: 'admin',
                    enrollmentSecret: 'adminpw',
                    attr_reqs: [{name: "role", optional: true}]
                }).then((enrollment) => {
                    console.log('Successfully enrolled admin user "admin"');
                    

                    var channel = client.getChannel("mychannel");
                    if(!channel) {
                        let message = util.format('Channel %s was not defined in the connection profile', channelName);
                        logger.error(message);
                        throw new Error(message);
                    }
                    var request = {
                        targets : ["peer0.org1.example.com"], //queryByChaincode allows for multiple targets
                        chaincodeId: "fabcar",
                        fcn: "queryAllCars",
                        args: [''],
                        channelId: "mychannel",
                        transientMap: new Date()
                    };
                    channel.queryByChaincode(request, true)
                    .then((resp) => {
                        console.log("query res----------------"+ resp);
                        console.log(resp);
                    });


                    // client.createUser(
                    //     {username: 'admin',
                    //         mspid: 'Org1MSP',
                    //         cryptoContent: { privateKeyPEM: enrollment.key.toBytes(), signedCertPEM: enrollment.certificate }
                    //     })
                    // .then((resp) => {
                        // // // // // client.setUserContext({username:"admin", password:"adminpw"})
                        // // // // // .then((resp) => {
                        // // // // //     console.log(resp);

                                                       

                           
                            
                            
                        // // // // //     client.getUserContext("admin", true)
                        // // // // //     .then((resp) => {
                        // // // // //         // send query
                        // // // // //         console.log("user context----------------"+ resp);
                        // // // // //         var uname= "user2";
                        // // // // //         caClient.register({
                        // // // // //         enrollmentID: uname,
                        // // // // //         affiliation: 'org1.dept1',
                        // // // // //         attrs: [{name: "role", value: "buyer", ecert: true}]
                        // // // // //         }, resp)
                        // // // // //         .then((password) => {
                        // // // // //             console.log("user registered----"+ resp);
                                    
                        // // // // //             caClient.enroll({enrollmentID: uname, enrollmentSecret: password,
                        // // // // //                 attr_reqs: [{name: "role", optional: true}]
                        // // // // //             })
                        // // // // //             .then((enrollment) => {
                        // // // // //                 console.log("enrolled user--------------------"+ enrollment.key.toBytes());
                                        
                        // // // // //                 // caClient.createUser(
                        // // // // //                 //     {username: uname,
                        // // // // //                 //     mspid: 'Org1MSP',
                        // // // // //                 //     cryptoContent: { privateKeyPEM: enrollment.key.toBytes(), signedCertPEM: enrollment.certificate }
                        // // // // //                 //     })
                        // // // // //                 // .then((resp) => {
                        // // // // //                 //     console.log("user created----------------"+ resp);
                                            
                        // // // // //                 // });

                        // // // // //                 // // // client.setUserContext({username:uname, password:password})
                        // // // // //                 // // // .then((resp) => {
                        // // // // //                 // // //     console.log("user-1-context---------"+ resp);   
                                            
                                            
    
                        // // // // //                     var channel = client.getChannel("mychannel");
                        // // // // //                     if(!channel) {
                        // // // // //                         let message = util.format('Channel %s was not defined in the connection profile', channelName);
                        // // // // //                         logger.error(message);
                        // // // // //                         throw new Error(message);
                        // // // // //                     }
                        // // // // //                     var request = {
                        // // // // //                         targets : ["peer0.org1.example.com"], //queryByChaincode allows for multiple targets
                        // // // // //                         chaincodeId: "fabcar",
                        // // // // //                         fcn: "queryAllCars",
                        // // // // //                         args: [''],
                        // // // // //                         channelId: "mychannel",
                        // // // // //                         transientMap: new Date()
                        // // // // //                     };
                        // // // // //                     channel.queryByChaincode(request, true)
                        // // // // //                     .then((resp) => {
                        // // // // //                         console.log("query res----------------"+ resp);
                        // // // // //                         console.log(resp);
                        // // // // //                     });
    
                        // // // // //                 // // // });
                        // // // // //             });


                                   
                        // // // // //         }); 


                                
                        // // // // //     });
                            
                        // // // // // });
                    //});
                   
                        
                    /*
                    
                    */

                });
            //});

            
        }
    }).then(() => {
        console.log('Assigned the admin user to the fabric client ::' + admin_user.toString());
    }).catch((err) => {
        console.error('Failed to enroll admin: ' + err);
    });

        
    });

    
    /*
// create the key value store as defined in the fabric-client/config/default.json 'key-value-store' setting
Fabric_Client.newDefaultKeyValueStore({ path: store_path
}).then((state_store) => {
    // assign the store to the fabric client
    fabric_client.setStateStore(state_store);
    var crypto_suite = Fabric_Client.newCryptoSuite();
    // use the same location for the state store (where the users' certificate are kept)
    // and the crypto store (where the users' keys are kept)
    var crypto_store = Fabric_Client.newCryptoKeyStore({path: store_path});
    crypto_suite.setCryptoKeyStore(crypto_store);
    fabric_client.setCryptoSuite(crypto_suite);
    var	tlsOptions = {
    	trustedRoots: [],
    	verify: false
    };
    // be sure to change the http to https when the CA is running TLS enabled
    fabric_ca_client = new Fabric_CA_Client('http://localhost:7054', tlsOptions , 'ca.example.com', crypto_suite);

    // first check to see if the admin is already enrolled
    return fabric_client.getUserContext('admin', true);
}).then((user_from_store) => {
    if (user_from_store && user_from_store.isEnrolled()) {
        console.log('Successfully loaded admin from persistence');
        admin_user = user_from_store;
        return null;
    } else {
        // need to enroll it with CA server
        return fabric_ca_client.enroll({
          enrollmentID: 'admin',
          enrollmentSecret: 'adminpw'
        }).then((enrollment) => {
          console.log('Successfully enrolled admin user "admin"');
          return fabric_client.createUser(
              {username: 'admin',
                  mspid: 'Org1MSP',
                  cryptoContent: { privateKeyPEM: enrollment.key.toBytes(), signedCertPEM: enrollment.certificate }
              });
        }).then((user) => {
          admin_user = user;
          return fabric_client.setUserContext(admin_user);
        }).catch((err) => {
          console.error('Failed to enroll and persist admin. Error: ' + err.stack ? err.stack : err);
          throw new Error('Failed to enroll admin');
        });
    }
}).then(() => {
    console.log('Assigned the admin user to the fabric client ::' + admin_user.toString());
}).catch((err) => {
    console.error('Failed to enroll admin: ' + err);
});


*/