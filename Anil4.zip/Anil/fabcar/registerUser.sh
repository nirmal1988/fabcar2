


#FABRIC_CA_SERVER_CA_CERTFILE=/etc/hyperledger/fabric-ca-server-config/ca.org1.example.com-cert.pem

#fabric-ca-client enroll -d -u http://admin@ca.example.com:7054

#fabric-ca-client register -d --id.name buyer --id.secret adminpw --id.attrs "hf.Registrar.Roles=client,hf.Registrar.Attributes=*,hf.Revoker=true,role=buyer:ecert,abac.init=true:ecert"
     
#fabric-ca-client enroll -d -u http://buyer:adminpw@ca.example.com:7054

CORE_PEER_LOCALMSPID=Org1MSP
CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@org1.example.com/msp
CORE_PEER_ADDRESS=peer0.org1.example.com:7051
CORE_PEER_LOCALMSPID=Org1MSP
peer chaincode query -C mychannel -n fabcar -c '{"Args":["queryAllCars"]}'