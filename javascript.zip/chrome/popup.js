var _css = [];
var _styles = [];
var _defaultStyle = {};
document.addEventListener('DOMContentLoaded', function() {
	
	console.log('Load all styles');
	setTimeout(() => {
		SelectionStore.indexedDB.getAllCSS(null, function(css){
			_css = css
		});
	
		SelectionStore.indexedDB.getAllStyles(null, function(styles){
			console.log('styles', styles);
			_styles = styles;
			styles.forEach(function(s){
				var isDefault = '';
				if(s.isDefault == 1){
					_defaultStyle = s;
					isDefault = 'selected';
				}
				$('#ddlStyles').append('<option '+ isDefault +' value="'+ s.styleId +'">'+ s.name +'</option>');
			});
			console.log('_defaultStyle', _defaultStyle);
			var _selectedStyle = _css.filter(x => x.styleId === _defaultStyle.styleId);
			console.log('_selectedStyle', _selectedStyle);
			var _defaultStyle = '';
			_selectedStyle.forEach(function(sc){
				_defaultStyle += sc.property +':'+ sc.value +';';
			});
			$('#defaultStyleList').html('<div style="'+ _defaultStyle +'"><b>Default Style: </b>Sample Text</div>');
		});
	}, 1000);
	
	setTimeout(function(){
		$('#ddlStyles').bind('change', function(){
			var styleId = $(this).val();
			var _defaultStyle = '';
			var _selectedStyle = _css.filter(x => Number(x.styleId) === Number(styleId));
			console.log('_selectedStyle', _selectedStyle);
			_selectedStyle.forEach(function(sc){
				_defaultStyle += sc.property +':'+ sc.value +';';
			});
			$('#defaultStyleList').html('<div style="'+ _defaultStyle +'"><b>Default Style: </b>Sample Text</div>');
		
			// Update Default style
			var _updatedStyle = _styles.filter(x => Number(x.styleId) === Number(styleId))[0];
			var _oldDefStyle = _styles.filter(x => Number(x.isDefault) === 1)[0];
			_updatedStyle.isDefault = 1;
			_oldDefStyle.isDefault = 0;
			SelectionStore.indexedDB.defaultStyle = _updatedStyle;
			SelectionStore.indexedDB.updateStyle(_updatedStyle);
			SelectionStore.indexedDB.updateStyle(_oldDefStyle);
		});
	}, 3000);
	
  }, false);