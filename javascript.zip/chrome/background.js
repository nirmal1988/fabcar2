// background.js
var tabURL = "";
chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
    if (msg.text == "what is my tab_id?") {
			tabURL = sender.tab.url;
		// Create model popup html
		var _model = '<div id="dialog-confirm" title="Options:"> '+
					'<p><span class="ui-icon ui-icon-alert" style="float:left; margin:0px -16px 0px 0px;"></span>Click Remove if not needed.</p>'+
					'</div>';
		
		chrome.tabs.executeScript(sender.tab.id, {code: 'setTimeout(function(){ $(document.body).append(\''+ _model +'\'); $(".ext-added").bind("click", function(){ showOptions(this); }); }, 3000);'});
        sendResponse({tab: sender.tab});
		
    }
	
	else if (msg.text == "applyCSS") {
		
		chrome.tabs.insertCSS(sender.tab.id, {code: msg.cssText});
		
    }
	else if(msg.text == "addSelections"){
		SelectionStore.indexedDB.getDefaultStyle();
		msg._obj.url = tabURL != undefined && tabURL != typeof(undefined) ? tabURL : msg._obj.tabURL;
		setTimeout(() => {
			SelectionStore.indexedDB.addSelection(msg._obj, function(response){
				chrome.tabs.query({active: true, currentWindow: true}, function(tabs){
						chrome.tabs.sendMessage(tabs[0].id, {message: "addSelectionsResult", data: response}, function(response) {});  
				});
			});
		}, 500);
	 }
	 else if(msg.text == "getSelections"){
		console.log("get all");
		SelectionStore.indexedDB.getAllSelections(msg.data, function(obj){
			console.log(obj);
			chrome.tabs.query({active: true, currentWindow: true}, function(tabs){
					chrome.tabs.sendMessage(tabs[0].id, {message: "getSelectionsResult", data: obj}, function(response) {});  
			});
		});
	 }
	 else if(msg.text == "getSelectionsDesign"){
		console.log("get design");
		SelectionStore.indexedDB.getSelectionsStyle(msg.selections, function(obj){
			console.log('css', obj);
			chrome.tabs.query({active: true, currentWindow: true}, function(tabs){
					chrome.tabs.sendMessage(tabs[0].id, {message: "getSelectionsDesignResult", data: obj}, function(response) {});  
			});
		});
	 }
});

var SelectionStore = {};
window.indexedDB = window.indexedDB || window.webkitIndexedDB ||
								window.mozIndexedDB;

if ('webkitIndexedDB' in window) {
	window.IDBTransaction = window.webkitIDBTransaction;
	window.IDBKeyRange = window.webkitIDBKeyRange;
}

SelectionStore.indexedDB = {};
SelectionStore.indexedDB.db = null;
SelectionStore.indexedDB.defaultStyle = {};

SelectionStore.indexedDB.onerror = function(e) {
	console.log(e);
};

SelectionStore.indexedDB.open = function() {
	var version = 5;
	var request = indexedDB.open("selections", version);

	// We can only create Object stores in a versionchange transaction.
	request.onupgradeneeded = function(e) {
		var db = e.target.result;

		// A versionchange transaction is started automatically.
		e.target.transaction.onerror = SelectionStore.indexedDB.onerror;

		if(db.objectStoreNames.contains("selection")) {
			db.deleteObjectStore("selection");
		}

		var store = db.createObjectStore("selection",
		 {keyPath: "selId", autoIncrement: true});
		 store.createIndex("url","url", {unique:false});			


		 if(db.objectStoreNames.contains("objects")) {
			db.deleteObjectStore("objects");
			}

		var store = db.createObjectStore("objects",
		 {keyPath: "objId", autoIncrement: true});
		 store.createIndex("selId","selId", {unique:false});			

		 if(db.objectStoreNames.contains("selectionStyle")) {
			db.deleteObjectStore("selectionStyle");
			}

		var store = db.createObjectStore("selectionStyle",
		 {keyPath: "selStyleId", autoIncrement: true});

		 if(db.objectStoreNames.contains("styles")) {
			db.deleteObjectStore("styles");
			}

		var store = db.createObjectStore("styles",
		 {keyPath: "styleId", autoIncrement: true});

		 if(db.objectStoreNames.contains("css")) {
			db.deleteObjectStore("css");
			}

		var store = db.createObjectStore("css",
		 {keyPath: "cssId", autoIncrement: true});

	};

	request.onsuccess = function(e) {
		SelectionStore.indexedDB.db = e.target.result;
		SelectionStore.indexedDB.getAllTodoItems();
	};

	request.onerror = SelectionStore.indexedDB.onerror;
};

SelectionStore.indexedDB.addSelection = function(_obj, callback) {
	var db = SelectionStore.indexedDB.db;
	var trans = db.transaction(["selection"], "readwrite");
	var store = trans.objectStore("selection");
	console.log('add selection', _obj);
	var data = {
		url: _obj.url,
		target: _obj.target,
		selectedText: _obj.selectedText,
		isActive: 1,
		"timeStamp": new Date().getTime()
	};

	var request = store.put(data);

	request.onsuccess = function(e) {
		console.log(e.target.result);

		$((SelectionStore.indexedDB.wrapBeginningEndingHtml(_obj.objectsHtml)).children).each(function(){
			if(this != typeof(undefined) && $(this).html() != '' && $(this).html() != null && $(this).html() != typeof(undefined)){
				SelectionStore.indexedDB.addObject({selId: e.target.result, object: $(this).html()});
			}
		});
		console.log('SelectionStore.indexedDB.defaultStyle.styleId', SelectionStore.indexedDB.defaultStyle.styleId);
		SelectionStore.indexedDB.addSelectionStyle({selId: e.target.result, styleId: SelectionStore.indexedDB.defaultStyle.styleId});
		callback(e.target.result);
	};

	request.onerror = function(e) {
		console.log("Error Adding: ", e);
	};
};

SelectionStore.indexedDB.addObject = function(_obj) {
	var db = SelectionStore.indexedDB.db;
	var trans = db.transaction(["objects"], "readwrite");
	var store = trans.objectStore("objects");

	var data = {
		selId: _obj.selId,
		object: _obj.object,
		"timeStamp": new Date().getTime()
	};

	var request = store.put(data);

	request.onsuccess = function(e) {
		console.log(e.target.result);
	};

	request.onerror = function(e) {
		console.log("Error Adding: ", e);
	};
};

SelectionStore.indexedDB.addSelectionStyle = function(_obj) {
	var db = SelectionStore.indexedDB.db;
	var trans = db.transaction(["selectionStyle"], "readwrite");
	var store = trans.objectStore("selectionStyle");

	var data = {
		selId: _obj.selId,
		styleId: _obj.styleId,
		"timeStamp": new Date().getTime()
	};

	var request = store.put(data);

	request.onsuccess = function(e) {
		console.log(e.target.result);
	};

	request.onerror = function(e) {
		console.log("Error Adding: ", e);
	};
};

SelectionStore.indexedDB.addStyle = function(_obj) {
	var db = SelectionStore.indexedDB.db;
	var trans = db.transaction(["styles"], "readwrite");
	var store = trans.objectStore("styles");

	var data = {
		name: _obj.name,
		isDefault: _obj.isDefault,
		"timeStamp": new Date().getTime()
	};

	var request = store.put(data);

	request.onsuccess = function(e) {
		console.log(e.target.result);
		setTimeout(() => {
			SelectionStore.indexedDB.addCSS({styleId: e.target.result, property: _obj.property, value: _obj.value});
		}, 1000);
	};

	request.onerror = function(e) {
		console.log("Error Adding: ", e);
	};
};


SelectionStore.indexedDB.updateStyle = function(data) {
	var db = SelectionStore.indexedDB.db;
	var trans = db.transaction(["styles"], "readwrite");
	var store = trans.objectStore("styles");

	var request = store.put(data);

	request.onsuccess = function(e) {
		console.log('style updated', e.target.result);
	};

	request.onerror = function(e) {
		console.log("Error Adding: ", e);
	};
};


SelectionStore.indexedDB.addCSS = function(_obj) {
	var db = SelectionStore.indexedDB.db;
	var trans = db.transaction(["css"], "readwrite");
	var store = trans.objectStore("css");

	var data = {
		styleId: _obj.styleId,
		property: _obj.property,
		value: _obj.value,
		"timeStamp": new Date().getTime()
	};

	var request = store.put(data);

	request.onsuccess = function(e) {
		console.log(e.target.result);
	};

	request.onerror = function(e) {
		console.log("Error Adding: ", e);
	};
};

SelectionStore.indexedDB.deleteTodo = function(id) {
	var db = SelectionStore.indexedDB.db;
	var trans = db.transaction(["selection"], "readwrite");
	var store = trans.objectStore("selection");

	var request = store.delete(id);

	request.onsuccess = function(e) {
		SelectionStore.indexedDB.getAllTodoItems();
	};

	request.onerror = function(e) {
		console.log("Error Adding: ", e);
	};
};


SelectionStore.indexedDB.setInitialStyles = function() {
	var db = SelectionStore.indexedDB.db;
	var trans = db.transaction(["styles"], "readwrite");
	var store = trans.objectStore("styles");

	// Get everything in the store;
	var keyRange = IDBKeyRange.lowerBound(0);
	var cursorRequest = store.openCursor(keyRange);

	cursorRequest.onsuccess = function(e) {
		var result = e.target.result;
		console.log("setInitialStyles");
		console.log(result);
		if(result == null){
			SelectionStore.indexedDB.addStyle({
				name: 'Style-1',
				isDefault: 1,
				property: 'background-color',
				value: 'yellow'
			});

			SelectionStore.indexedDB.addStyle({
				name: 'Style-2',
				isDefault: 0,
				property: 'background-color',
				value: 'green'
			});
		}
	};

	cursorRequest.onerror = SelectionStore.indexedDB.onerror;
};

SelectionStore.indexedDB.setInitialCSS = function() {
	var db = SelectionStore.indexedDB.db;
	var trans = db.transaction(["styles"], "readwrite");
	var store = trans.objectStore("styles");

	// Get everything in the store;
	var keyRange = IDBKeyRange.lowerBound(0);
	var cursorRequest = store.openCursor(keyRange);
	var _counter = 1;
	cursorRequest.onsuccess = function(e) {
		var result = e.target.result;
		console.log("setInitialCSS");
		console.log(result);
		if(!!result == false)
			return;
		if(result != null){
			SelectionStore.indexedDB.addCSS({
				styleId: result.value.styleId,
				property: 'background-color',
				value: _counter == 1 ? 'yellow' : 'green'
			});
			_counter++;
		}
		result.continue();
	};

	cursorRequest.onerror = SelectionStore.indexedDB.onerror;
};



SelectionStore.indexedDB.getDefaultStyle = function() {
	var db = SelectionStore.indexedDB.db;
	var trans = db.transaction(["styles"], "readwrite");
	var store = trans.objectStore("styles");

	// Get everything in the store;
	var keyRange = IDBKeyRange.lowerBound(0);
	var cursorRequest = store.openCursor(keyRange);
	cursorRequest.onsuccess = function(e) {
		var result = e.target.result;
		if(!!result == false)
			return;
	 if(result.value.isDefault == 1){
			SelectionStore.indexedDB.defaultStyle = result.value;
			console.log('default style');
			console.log(SelectionStore.indexedDB.defaultStyle);
		}
		else result.continue();
	};

	cursorRequest.onerror = SelectionStore.indexedDB.onerror;
};

SelectionStore.indexedDB.getAllSelections = function(data, callback) {
	var db = SelectionStore.indexedDB.db;
	var trans = db.transaction(["selection"], "readonly");
	var store = trans.objectStore("selection");
	var index = store.index("url");
	// Get everything in the store;
	var keyRange = IDBKeyRange.only(tabURL);
	var cursorRequest = index.openCursor(keyRange);
	var selectionsArr = [];
	console.log('selected now-', data);
	console.log('data url', tabURL);
	var currentSel = 0;
	if(data != null && data != '' && data != undefined && data != 0 && data != typeof(undefined) && data > 0)
		currentSel = data;
	cursorRequest.onsuccess = function(e) {
		var result = e.target.result;
		if(!!result == false)
			{
				return SelectionStore.indexedDB.getAllObjects(selectionsArr, callback);
			};
			if(result.value.url == tabURL)
			{
				if(currentSel > 0 && currentSel == result.value.selId)
					selectionsArr.push(result.value);
				else if(currentSel == 0)
					selectionsArr.push(result.value);
			}
	  result.continue();
	};

	cursorRequest.onerror = SelectionStore.indexedDB.onerror;
};

SelectionStore.indexedDB.getAllObjects = function(selectionsArr, callback) {
	var db = SelectionStore.indexedDB.db;
	var trans = db.transaction(["objects"], "readonly");
	var store = trans.objectStore("objects");

	// Get everything in the store;
	var keyRange = IDBKeyRange.lowerBound(0);
	var cursorRequest = store.openCursor(keyRange);
	var objectsArr = [];
	cursorRequest.onsuccess = function(e) {
		var result = e.target.result;
		if(!!result == false)
			{
				console.log(objectsArr);
				return callback({ selections: selectionsArr, objects: objectsArr});
			};
			// check selection exists
			var selExists = selectionsArr.filter(function(o){return o.selId == result.value.selId});
			if(selExists != null && selExists != undefined && selExists != typeof(undefined) && selExists.length > 0)
					objectsArr.push(result.value);
	  result.continue();
	};

	cursorRequest.onerror = SelectionStore.indexedDB.onerror;
};


SelectionStore.indexedDB.getSelectionsStyle = function(selectionsArr, callback) {
	var db = SelectionStore.indexedDB.db;
	var trans = db.transaction(["selectionStyle"], "readonly");
	var store = trans.objectStore("selectionStyle");

	// Get everything in the store;
	var keyRange = IDBKeyRange.lowerBound(0);
	var cursorRequest = store.openCursor(keyRange);
	var selectionStyleArr = [];
	cursorRequest.onsuccess = function(e) {
		var result = e.target.result;
		if(!!result == false)
			{
				return SelectionStore.indexedDB.getSelectionsCSS({ selectionsArr: selectionsArr, selectionStyleArr: selectionStyleArr}, callback);
			};
			// check selection exists
			if(selectionsArr == null || selectionsArr == undefined || selectionsArr == typeof(undefined))
				selectionStyleArr.push(result.value);
			else{
				var selExists = selectionsArr.filter(function(o){return o.selId == result.value.selId});
				if(selExists != null && selExists != undefined && selExists != typeof(undefined) && selExists.length > 0)
					selectionStyleArr.push(result.value);
			}
	  result.continue();
	};

	cursorRequest.onerror = SelectionStore.indexedDB.onerror;
};

SelectionStore.indexedDB.getSelectionsCSS = function(data, callback) {
	var db = SelectionStore.indexedDB.db;
	var trans = db.transaction(["css"], "readonly");
	var store = trans.objectStore("css");

	// Get everything in the store;
	var keyRange = IDBKeyRange.lowerBound(0);
	var cursorRequest = store.openCursor(keyRange);
	var cssArr = [];
	cursorRequest.onsuccess = function(e) {
		var result = e.target.result;
		if(!!result == false)
			{
				return callback({ selections: data.selectionsArr, selectionStyle: data.selectionStyleArr, css: cssArr});
			};
			// check selection exists
			var selExists = data.selectionStyleArr.filter(function(o){return o.styleId == result.value.styleId});
			if(selExists != null && selExists != undefined && selExists != typeof(undefined) && selExists.length > 0)
				cssArr.push(result.value);
	  result.continue();
	};

	cursorRequest.onerror = SelectionStore.indexedDB.onerror;
};


SelectionStore.indexedDB.getAllStyles = function(data, callback) {
	var db = SelectionStore.indexedDB.db;
	var trans = db.transaction(["styles"], "readonly");
	var store = trans.objectStore("styles");

	// Get everything in the store;
	var keyRange = IDBKeyRange.lowerBound(0);
	var cursorRequest = store.openCursor(keyRange);
	var stylesArr = [];
	cursorRequest.onsuccess = function(e) {
		var result = e.target.result;
		if(!!result == false)
			{
				return callback(stylesArr);
			};
			stylesArr.push(result.value);
	  result.continue();
	};

	cursorRequest.onerror = SelectionStore.indexedDB.onerror;
};

SelectionStore.indexedDB.getAllCSS = function(data, callback) {
	var db = SelectionStore.indexedDB.db;
	var trans = db.transaction(["css"], "readonly");
	var store = trans.objectStore("css");

	// Get everything in the store;
	var keyRange = IDBKeyRange.lowerBound(0);
	var cursorRequest = store.openCursor(keyRange);
	var cssArr = [];
	cursorRequest.onsuccess = function(e) {
		var result = e.target.result;
		if(!!result == false)
			{
				console.log('cssArr', cssArr);
				return callback(cssArr);
			};
			console.log('result.value', result.value);
			cssArr.push(result.value);
	  result.continue();
	};

	cursorRequest.onerror = SelectionStore.indexedDB.onerror;
};

SelectionStore.indexedDB.getAllTodoItems = function() {
	//var todos = document.getElementById("todoItems");
	//todos.innerHTML = "";

	var db = SelectionStore.indexedDB.db;
	var trans = db.transaction(["selection"], "readwrite");
	var store = trans.objectStore("selection");

	// Get everything in the store;
	var keyRange = IDBKeyRange.lowerBound(0);
	var cursorRequest = store.openCursor(keyRange);

	cursorRequest.onsuccess = function(e) {
		var result = e.target.result;
		if(!!result == false)
			return;

		renderTodo(result.value);
		result.continue();
	};

	cursorRequest.onerror = SelectionStore.indexedDB.onerror;
};

function renderTodo(row) {
	//var todos = document.getElementById("todoItems");
	var li = document.createElement("li");
	var a = document.createElement("a");
	var t = document.createTextNode(row.text);

	a.addEventListener("click", function() {
		SelectionStore.indexedDB.deleteTodo(row.timeStamp);
	}, false);

	a.href = "#";
	a.textContent = " [Delete]";
	li.appendChild(t);
	li.appendChild(a);
	//todos.appendChild(li);
}

function init() {
	SelectionStore.indexedDB.open();
}
init();

setTimeout(() => {
	SelectionStore.indexedDB.setInitialStyles();
	SelectionStore.indexedDB.getDefaultStyle();
}, 1000);

SelectionStore.indexedDB.wrapBeginningEndingHtml = function (txtHtml){
	if(txtHtml.startsWith("<") == false || txtHtml.endsWith(">") == false){
		var finalText = '';
		var container = document.createElement("div"); 
		var beginningText = txtHtml.substring(0,txtHtml.indexOf('<'));
		finalText = beginningText != '' ? txtHtml.replace(beginningText, '<p>'+ beginningText +'</p>') : txtHtml;
		
		var endingText = finalText.substring(finalText.lastIndexOf('>')+1, finalText.length);
		finalText = endingText != '' ? finalText.replace(endingText, '<p>'+ endingText +'</p>') : finalText;
		container.innerHTML = finalText;
		return container;
	}
	else 
		return txtHtml;
};