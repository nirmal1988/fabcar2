// content.js
var tabURL = "";
var db = openDatabase('mydb8', '1.0', 'Selections', 2 * 1024 * 1024);

//



document.addEventListener('mouseup',function(event)
{
	var sel = window.getSelection().toString();
	console.log(sel);
	var objectsHtml = getSelectionHtml();
	console.log(objectsHtml);
	var _parentId = "";//findParentId(event.target);
	console.log(_parentId);

	if(sel == null || sel == '' || sel == undefined || sel == typeof(undefined)) return true;

	var _obj = {
		selectedText: sel,
		objectsHtml: $(objectsHtml).html(),
		target: _parentId,
		tabURL: tabURL,
	};

	chrome.runtime.sendMessage({ text: "addSelections", _obj: _obj }, obj => {
	});
	
	//return false;
	/*
	db.transaction(function (tx) {
		
		tx.executeSql(
            'INSERT INTO Selections (url, target, selectedText, isActive) VALUES (?,?,?,1)',
            [tabURL, _parentId, sel],
            function(tx, results){
                console.log('Returned ID: ' + results.insertId);
			
				$((wrapBeginningEndingHtml($(objectsHtml).html())).children).each(function(){
					if(this != typeof(undefined) && $(this).html() != '' && $(this).html() != null && $(this).html() != typeof(undefined)){
						   tx.executeSql(
								 'INSERT INTO Objects (selId, object) VALUES (?,?)',
								 [results.insertId, $(this).html()],
								 function(tx, results){
									 console.log('object '+ results.insertId);
								 },
								 errorCB
							 );
					   }
				});
				
				fillCSS(results.insertId);
				
				markIt('selId', results.insertId);
            },
            errorCB
        );
		
	  
	});
	*/
	
	
})

chrome.runtime.sendMessage({ text: "what is my tab_id?" }, obj => {
   console.log('My tabId is', obj.tab);
   tabURL = obj.tab.url;
	 console.log(tabURL);
	 
	 
chrome.runtime.sendMessage({ text: "getSelections" }, obj => {
});

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
	
  if(request.message == "addSelectionsResult"){
		chrome.runtime.sendMessage({ text: "getSelections", data: request.data }, obj => {
		});
	}
	else if(request.message == "getSelectionsResult"){
		designIt(request.data);
		chrome.runtime.sendMessage({ text: "getSelectionsDesign", selections: request.data.selections }, obj => {
		});
	}
	else if(request.message == "getSelectionsDesignResult"){
		setCSS(request.data);
	}

});

		
});

function designIt(data){
	for (var s = 0; s < data.selections.length; s++){
		var selectedObjects = [];
		//filter by selid
		for (var o = 0; o < data.objects.length; o++){
			if(data.objects[o].selId == data.selections[s].selId)
				selectedObjects.push(data.objects[o]);
		}
		console.log(selectedObjects);
		
		selectedObjects = devideObjects(selectedObjects);
		
		var highestMatch = findMatchingParent(selectedObjects);
		highestMatch.forEach(function(o){
			for (j = 0; j < selectedObjects.length; j++){
			 var objFoundHtml = $(o.ele).html();
		 
			 if(objFoundHtml != null && objFoundHtml != '' && objFoundHtml != undefined){
				 if(objFoundHtml.indexOf(selectedObjects[j].object) > -1){
					 var updatedObjHtml = objFoundHtml.replace(selectedObjects[j].object, "<ext-add class='ext-added' id='ext-added-sel_"+ selectedObjects[j].selId +"'>"+ selectedObjects[j].object +"</ext-add>");
					 
					 $(o.ele).html(updatedObjHtml);
				 }
				 else{
					 console.log('index not matching');
				 }
			 }
			 else{
				 console.log('----------not found');
			 }
			}
		});
		
}
	
}

function setCSS(data){
	var cssText = "";
	data.selectionStyle.forEach(function(o){
		var selectedStyle = o;
		var currentSelCSS = data.css.filter(function(o){return o.styleId == selectedStyle.styleId})
		if(currentSelCSS != null && currentSelCSS != undefined && currentSelCSS != typeof(undefined) && currentSelCSS.length > 0)
		{
			currentSelCSS.forEach(function(c){
				cssText +=  "#ext-added-sel_"+ selectedStyle.selId +"{"+ c.property +":"+ c.value +" !important;}";
			});
		}
	});
	console.log('cssText', cssText);
	chrome.runtime.sendMessage({ text: "applyCSS", cssText: cssText }, (data) => {
		console.log('css set');
	});
}

function getSelectionHtml() {
    var html = "";
	var container = document.createElement("div");
    if (typeof window.getSelection != "undefined") {
        var sel = window.getSelection();
        if (sel.rangeCount) {
            for (var i = 0, len = sel.rangeCount; i < len; ++i) {
                container.appendChild(sel.getRangeAt(i).cloneContents());
            }
            html = container.innerHTML;
        }
    } else if (typeof document.selection != "undefined") {
        if (document.selection.type == "Text") {
            html = document.selection.createRange().htmlText;
			container.appendChild(document.selection.createRange().htmlText);
        }
    }
    return container;
}

function errorCB(err, e, t){
	console.log(e);
}

function escapeHtml(unsafe) {
	return unsafe
		 .replace(/&/g, "&amp;")
		 .replace(/</g, "&lt;")
		 .replace(/>/g, "&gt;")
		 .replace(/"/g, "&quot;")
		 .replace(/'/g, "&#039;");
}

function findParentId(obj){
	if($(obj).attr('id') != "" && $(obj).attr('id') != null && $(obj).attr('id') != undefined && $(obj).attr('id') != typeof(undefined)){
		var inDocument = $(document).find('#'+ $(obj).attr('id'));
		if(inDocument != null && inDocument.length == 1){
			return $(obj).attr('id');
		}
		else{
			return findParentId($(obj).parent());
		}
	}
	else return findParentId($(obj).parent());
}	

function findMatchingParent(selectedObjects){
	var matchedElements = [];
	$(document).find('*').each(function(){
		var currentElement = {ele: $(this), len: $(this).html().length};
		var matchCount = 0;
		for (j = 0; j < selectedObjects.length; j++){
			if($(this).html().indexOf(selectedObjects[j].object) > -1)
				matchCount++;
		}
		
		if(matchCount > 0){
			currentElement.matchCount = matchCount;
			matchedElements.push(currentElement);
		}
	});
	
	console.log(matchedElements);
	
	var maxCount = Math.max.apply(Math, matchedElements.map(function(o) { return o.matchCount; }));
	var minLen = Math.min.apply(Math, matchedElements.filter(function(o){return o.matchCount == maxCount}).map(function(o) { return o.len; }));
	
	var highestMatch = matchedElements.filter(function(o){return o.matchCount == maxCount && o.len == minLen});
	
	return highestMatch;
}

var devidedObjects = [];
function devideObjects(selectedObjects){
	devidedObjects = [];
	selectedObjects.forEach(function(o){
		recursiveDevide(o);
	});
	return devidedObjects;
}

function recursiveDevide(o){
	if(isHTML(o.object)){
		var a = document.createElement('div'); 
		a.innerHTML = trimHTML(o.object, o);
		$(a).find('*').each(function(){
			if(isHTML($(this).html()) == false){
				devidedObjects.push({objId: o.objId, selId: o.selId, object: $(this).html()});
			}
			else{
				// extract beginning and ending text
				if($(this).html().startsWith("<") == false || $(this).html().endsWith(">") == false){
					recursiveDevide({objId: o.objId, selId: o.selId, object: trimHTML($(this).html(), o)});
				}
				else{
					recursiveDevide({objId: o.objId, selId: o.selId, object: $(this).html()});
				}
			}
		});
	}
	else{
		devidedObjects.push(o);
	}
}


function isHTML(str) {
  var a = document.createElement('div');
  a.innerHTML = str;
  for (var c = a.childNodes, i = c.length; i--; ) {
    if (c[i].nodeType == 1) return true; 
  }
  return false;
}

function trimHTML(txtHtml, o){
	if(txtHtml.startsWith("<") == false || txtHtml.endsWith(">") == false){
		var finalText = '';
		var beginningText = txtHtml.substring(0,txtHtml.indexOf('<'));
		
		finalText = beginningText != '' ? txtHtml.replace(beginningText, '') : txtHtml;
		
		var endingText = finalText.substring(finalText.lastIndexOf('>')+1, finalText.length);
		
		finalText = endingText != '' ? finalText.replace(endingText, '') : finalText;
		
		devidedObjects.push({objId: o.objId, selId: o.selId, object: beginningText});
		devidedObjects.push({objId: o.objId, selId: o.selId, object: endingText});
		return finalText;
	}
	else 
		return txtHtml;
}

function wrapBeginningEndingHtml(txtHtml){
	if(txtHtml.startsWith("<") == false || txtHtml.endsWith(">") == false){
		var finalText = '';
		var container = document.createElement("div"); 
		var beginningText = txtHtml.substring(0,txtHtml.indexOf('<'));
		finalText = beginningText != '' ? txtHtml.replace(beginningText, '<p>'+ beginningText +'</p>') : txtHtml;
		
		var endingText = finalText.substring(finalText.lastIndexOf('>')+1, finalText.length);
		finalText = endingText != '' ? finalText.replace(endingText, '<p>'+ endingText +'</p>') : finalText;
		container.innerHTML = finalText;
		return container;
	}
	else 
		return txtHtml;
}

function showOptions(selection){
	$( "#dialog-confirm" ).dialog({
      resizable: false,
      height: "auto",
      width: 400,
      modal: true,
      buttons: {
        "Remove": function() {
          $( this ).dialog( "close" );
		  var _currentSelId = $(selection).attr('id').split('_');
		  if(_currentSelId != null && _currentSelId != undefined && _currentSelId != typeof(undefined) && _currentSelId.length > 1){
			  db.transaction(function (tx) {
				   tx.executeSql('UPDATE Selections SET isActive = 0 WHERE selId = ?', [_currentSelId[1]], function (tx, results) {
				   $(selection).attr('id', 'ext-added-removed');
				   console.log('removed...');
				   
				 }, null);
				});
		  }
        },
        Cancel: function() {
          $( this ).dialog( "close" );
        }
      }
    });
}

function testMe(){
	alert('test');
}

