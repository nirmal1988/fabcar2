// background.js
var db = openDatabase('mydb8', '1.0', 'Selections', 2 * 1024 * 1024);
chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
    if (msg.text == "what is my tab_id?") {
		
		// Create model popup html
		var _model = '<div id="dialog-confirm" title="Options:"> '+
					'<p><span class="ui-icon ui-icon-alert" style="float:left; margin:0px -16px 0px 0px;"></span>Click Remove if not needed.</p>'+
					'</div>';
		
		chrome.tabs.executeScript(sender.tab.id, {code: 'setTimeout(function(){ $(document.body).append(\''+ _model +'\'); $(".ext-added").bind("click", function(){ showOptions(this); }); }, 3000);'});
        sendResponse({tab: sender.tab});
		

    }
	
	else if (msg.text == "applyCSS") {
		
		chrome.tabs.insertCSS(sender.tab.id, {code: msg.cssText});
		
    }
	else if(msg.text == "getCount"){
		
		
		chrome.extension.onRequest.addListener(function(request, sender) {
		  console.log(request.message);
		});
		
	 db.transaction(function (tx) {
		tx.executeSql('SELECT * FROM Styles', [], function (tx, results) {
		   var styles = results.rows;
			   console.log('3');
		   tx.executeSql('SELECT * FROM CSS', [], function (tx, results) {
			   var _css = results.rows;
				   console.log('4');
			   var stylesHtml = "<div>";
			   for (i = 0; i < styles.length; i++){
				   var _cssStyle = '';
					for (j = 0; j < _css.length; j++){
						if(styles.item(i).styleId == _css.item(i).styleId)
							_cssStyle += _css.item(i).property +':'+ _css.item(i).value +';';
					}
					if(styles.item(i).isDefault == 1)
						_cssStyle += 'border:2px solid #000;'
					stylesHtml +=  "<span id='"+ styles.item(i).styleId +"' style='"+ _cssStyle +"'>"+ styles.item(i).name +"</span>";
			   }
				stylesHtml += "</div>"		
				console.log(stylesHtml);
				$('#styleList').html(stylesHtml);
			   
			}, null);
		   
		 }, null);
		
	 });
		
		sendResponse(222);
	}
});


