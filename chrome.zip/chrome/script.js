$('.ext-added').bind('click', function(){
	
	console.log('33');
	
});