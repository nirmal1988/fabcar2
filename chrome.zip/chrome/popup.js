var db = openDatabase('mydb8', '1.0', 'Selections', 2 * 1024 * 1024);
document.addEventListener('DOMContentLoaded', function() {
	db.transaction(function (tx) {

	chrome.tabs.query({active: true, currentWindow: true},function(tabs) {
		
		chrome.tabs.sendMessage(tabs[0].id, {message: "getStyles"}, function(result){ 
			
		});
	});
	
	chrome.runtime.onMessage.addListener(function(message,sender,sendResponse){
		console.log(message);
		if(message.type == "stylesResponse"){
			$('#styleList').html(message.data);
		}
	});
	
	});
	
	setTimeout(function(){
	$('#styleList').find('span.style').click(function(){
		var styleId = $(this).attr('id');
		var currentStyle = this;
		chrome.tabs.query({active: true, currentWindow: true},function(tabs) {
		
			chrome.tabs.sendMessage(tabs[0].id, {message: "setDefaultStyle", styleId: styleId}, function(result){ 
				$('#styleList').find('span.style').css('border', '0px');
				$(currentStyle).css('border','solid 2px #000');
			});
		});
	});
	}, 3000);
	
  }, false);