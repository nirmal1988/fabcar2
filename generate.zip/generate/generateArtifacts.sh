function deleteFolders (){
    rm -R crypto-config
    rm -R channel-artifacts

    mkdir crypto-config
    mkdir channel-artifacts
}

# Generates Org certs using cryptogen tool
function generateCerts (){
  which cryptogen
  if [ "$?" -ne 0 ]; then
    echo "cryptogen tool not found. exiting"
    exit 1
  fi
  echo
  echo "##########################################################"
  echo "##### Generate certificates using cryptogen tool #########"
  echo "##########################################################"

  cryptogen generate --config=./crypto-config.yaml
  if [ "$?" -ne 0 ]; then
    echo "Failed to generate certificates..."
    exit 1
  fi
  echo
}

# The `configtxgen tool is used to create four artifacts: orderer **bootstrap
# block**, fabric **channel configuration transaction**, and two **anchor
# peer transactions** - one for each Peer Org.
#
# The orderer block is the genesis block for the ordering service, and the
# channel transaction file is broadcast to the orderer at channel creation
# time.  The anchor peer transactions, as the name might suggest, specify each
# Org's anchor peer on this channel.
#
# Configtxgen consumes a file - ``configtx.yaml`` - that contains the definitions
# for the sample network. There are three members - one Orderer Org (``OrdererOrg``)
# and two Peer Orgs (``Org1`` & ``Org2``) each managing and maintaining two peer nodes.
# This file also specifies a consortium - ``SampleConsortium`` - consisting of our
# two Peer Orgs.  Pay specific attention to the "Profiles" section at the top of
# this file.  You will notice that we have two unique headers. One for the orderer genesis
# block - ``TwoOrgsOrdererGenesis`` - and one for our channel - ``TwoOrgsChannel``.
# These headers are important, as we will pass them in as arguments when we create
# our artifacts.  This file also contains two additional specifications that are worth
# noting.  Firstly, we specify the anchor peers for each Peer Org
# (``peer0.org1.example.com`` & ``peer0.org2.example.com``).  Secondly, we point to
# the location of the MSP directory for each member, in turn allowing us to store the
# root certificates for each Org in the orderer genesis block.  This is a critical
# concept. Now any network entity communicating with the ordering service can have
# its digital signature verified.
#
# This function will generate the crypto material and our four configuration
# artifacts, and subsequently output these files into the ``channel-artifacts``
# folder.
#
# If you receive the following warning, it can be safely ignored:
#
# [bccsp] GetDefault -> WARN 001 Before using BCCSP, please call InitFactories(). Falling back to bootBCCSP.
#
# You can ignore the logs regarding intermediate certs, we are not using them in
# this crypto implementation.

# Generate orderer genesis block, channel configuration transaction and
# anchor peer update transactions
function generateChannelArtifacts() {
  which configtxgen
  if [ "$?" -ne 0 ]; then
    echo "configtxgen tool not found. exiting"
    exit 1
  fi

  echo "##########################################################"
  echo "#########  Generating Orderer Genesis block ##############"
  echo "##########################################################"
  # Note: For some unknown reason (at least for now) the block file can't be
  # named orderer.genesis.block or the orderer will fail to launch!
  configtxgen -profile $PROFILE_NAME_GENESIS -outputBlock ./channel-artifacts/vehicleTrackerGenesis.block
  if [ "$?" -ne 0 ]; then
    echo "Failed to generate orderer genesis block...>>"
    exit 1
  fi
  
  echo
  echo "#################################################################"
  echo "### Generating channel configuration transaction 'channel.tx' ###"
  echo "#################################################################"
  
  configtxgen -profile $PROFILE_NAME_CHANNEL -outputCreateChannelTx ./channel-artifacts/vehicleTrackerChannel.tx -channelID $CHANNEL_NAME
  if [ "$?" -ne 0 ]; then
    echo "Failed to generate channel configuration transaction..."
    exit 1
  fi
  
  echo
  echo "##########################################################################################################"
  echo "#######    Generating anchor peer update for ManufacturerOrg1, DealerOrg1, ServiceCenterOrg1   ###########"
  echo "##########################################################################################################"
  
  configtxgen -profile $PROFILE_NAME_CHANNEL -outputAnchorPeersUpdate ./channel-artifacts/manufacturerOrg1MSPanchors.tx -channelID $CHANNEL_NAME -asOrg ManufacturerOrg1MSP
  if [ "$?" -ne 0 ]; then
    echo "Failed to generate anchor peer update for ManufacturerOrg1MSP..."
    exit 1
  fi

  configtxgen -profile $PROFILE_NAME_CHANNEL -outputAnchorPeersUpdate ./channel-artifacts/dealerOrg1MSPanchors.tx -channelID $CHANNEL_NAME -asOrg DealerOrg1MSP
  if [ "$?" -ne 0 ]; then
    echo "Failed to generate anchor peer update for DealerOrg1MSP..."
    exit 1
  fi

  configtxgen -profile $PROFILE_NAME_CHANNEL -outputAnchorPeersUpdate ./channel-artifacts/serviceCenterOrg1MSPanchors.tx -channelID $CHANNEL_NAME -asOrg ServiceCenterOrg1MSP
  if [ "$?" -ne 0 ]; then
    echo "Failed to generate anchor peer update for ServiceCenterOrg1MSP..."
    exit 1
  fi
  
  echo
}

export FABRIC_CFG_PATH=$PWD
export PROFILE_NAME_GENESIS=VehicleTrackerGenesis
export PROFILE_NAME_CHANNEL=VehicleTrackerChannel
export CHANNEL_NAME=vehicletrackerchannel

deleteFolders
generateCerts
generateChannelArtifacts